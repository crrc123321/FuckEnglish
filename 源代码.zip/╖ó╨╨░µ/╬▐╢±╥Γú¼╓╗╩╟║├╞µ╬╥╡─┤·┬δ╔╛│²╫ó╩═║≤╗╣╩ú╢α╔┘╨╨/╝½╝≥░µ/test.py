import os
os.system('mode con cols=42 lines=8')
import time
import difflib
import requests
import win32gui
from wxauto import *
def SimilarMatching(A,transback):
    a=difflib.SequenceMatcher(None,A,transback).quick_ratio()
    return a
def Headers():
    fway=r"C:\ProgramData\EnglishHelper"
    finame='Cookies.txt'
    fpath=os.path.join(fway,finame)
    with open(fpath,'r') as file:
        content=file.read()
    headers={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    "Cookie": content 
    }
    return(headers)
def GetWords():
    start_index = lstmsg[1].find("【单选】") + len("【单选】")
    end_index = lstmsg[1].find("[")
    gotword = lstmsg[1][start_index:end_index].strip()
    return gotword
def GetAndSend(gottenword,Headers):
    try:
        response=requests.post(trans,headers=Headers,data={'kw':gottenword})
        response.raise_for_status()
        data=response.json().get('data')
        return data[0]['v'] if data else None
    except Exception as e:
        print(f"抽风信息：{e}")
        return None
gradeanswer=0
errorsit=0
trans='https://fanyi.baidu.com/sug'
A=[]
B=[]
C=[]
D=[]
while True:
    handle=win32gui.FindWindow(None,'微信')
    if handle==0:
        print('\033c')
        print('微信都不打开，背个啥啊')
        print('快去打开微信再来找我')
        time.sleep(3)
        print('\033c')
        break
    print('\033c')
    print('异常情况数：',errorsit)
    gradeanswer=input('请输入要背单词的数量:')
    if gradeanswer=='':
        print('不打单词数量怎么背单词啊')
        time.sleep(1.5)
        print('\033c')
        continue
    elif '0' in gradeanswer or '1' in gradeanswer or '2' in gradeanswer or '3' in gradeanswer or '4' in gradeanswer or '5' in gradeanswer or '6' in gradeanswer or '7' in gradeanswer or '8' in gradeanswer or '9' in gradeanswer:
        if '.' in gradeanswer:
            print('单词数量怎么可能是小数')
            time.sleep(1.3)
            print('\033c')
            continue
        else:
            gradeanswer=int(gradeanswer)
    else:
        print('别瞎输，好好输')
        time.sleep(1)
        print('\033c')
        continue
    answered=0
    wx=WeChat()
    wx.ChatWith('在线签到助手')
    wx.SendMsg('背单词')
    while answered<gradeanswer:
        time.sleep(1.8)
        lstmsg=wx.GetAllMessage()[-1]
        wd=GetWords()
        hd=Headers()
        transback=GetAndSend(wd,hd)
        if "请在20秒内回复答案" in lstmsg[1]:
            a_start=lstmsg[1].find("A. ")+len("A. ")
            a_end=lstmsg[1].find("B. ")
            b_start=lstmsg[1].find("B. ")+len("B. ")
            b_end=lstmsg[1].find("C. ")
            c_start=lstmsg[1].find("C. ")+len("C. ")
            c_end=lstmsg[1].find("D. ")
            d_start=lstmsg[1].find("D. ")+len("D. ")
            d_end=lstmsg[1].find("====================")
            if type(transback) != type('test') or type(transback)==type(None):
                wx.SendMsg('C')
                print('百度翻译抽风，遇事不决就选C')
                answered+=1
                errorsit+=1
                continue
            opa=lstmsg[1][a_start:a_end].strip()
            A.append(opa)
            opb=lstmsg[1][b_start:b_end].strip()
            B.append(opb)
            opc=lstmsg[1][c_start:c_end].strip()
            C.append(opc)
            opd=lstmsg[1][d_start:d_end].strip()
            D.append(opd)
            strA="".join(A)
            strB="".join(B)
            strC="".join(C)
            strD="".join(D)
            sima=SimilarMatching(strA,transback)
            simb=SimilarMatching(strB,transback)
            simc=SimilarMatching(strC,transback)
            simd=SimilarMatching(strD,transback)
            if sima>simb and sima>simc and sima>simd:
                wx.SendMsg("A")
            elif simb>sima and simb>simc and simb>simd:
                wx.SendMsg("B")
            elif simc>sima and simc>simb and simc>simd:
                wx.SendMsg("C")
            else:
                wx.SendMsg("D")
            print('当前已背', answered+1 ,'个单词')
        elif "验证单词学习行为" in lstmsg[1]:
            start_index = lstmsg[1].find("请回复") + len("请回复")
            end_index=lstmsg[1].find("验证单词学习行为")
            response=lstmsg[1][start_index:end_index].strip()       
            wx.SendMsg(response)
            answered-=1
        else:
            wx.SendMsg("背单词")
            answered-=1
        A.clear()
        B.clear()
        C.clear()
        D.clear()
        answered+=1