#调整窗口大小
import os
os.system('mode con cols=42 lines=8')

#导入所需模块
import time
import difflib
import requests
import win32gui
from wxauto import *

#定义相似算法函数
def SimilarMatching(A,transback):
    a=difflib.SequenceMatcher(None,A,transback).quick_ratio()
    return a

#定义报头函数
def Headers():
    #定义路径、文件名和path
    fway=r"C:\ProgramData\EnglishHelper"
    finame='Cookies.txt'
    fpath=os.path.join(fway,finame)

    #使用只读权限打开文件，设置content变量并作为报头一部分
    with open(fpath,'r') as file:
        content=file.read()
    headers={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    "Cookie": content 
    }
    return(headers)

#获取切片后的单词，以备发送
def GetWords():
    #设置起始位置
    start_index = lstmsg[1].find("【单选】") + len("【单选】")
    end_index = lstmsg[1].find("[")

    #获取字符串格式的单词本体并返回值
    gotword = lstmsg[1][start_index:end_index].strip()
    return gotword

#将获取到的单词发送至翻译提供商，并取得翻译结果
def GetAndSend(gottenword,Headers):
    try:
        response=requests.post(trans,headers=Headers,data={'kw':gottenword})
        response.raise_for_status()
        data=response.json().get('data')
        return data[0]['v'] if data else None
    except Exception as e:
        print(f"抽风信息：{e}")
        return None










#定义函数区
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#设置变量区





#设置目标单词数量
gradeanswer=0

#设置错误情况数
errorsit=0

#设置翻译API提供商
trans='https://fanyi.baidu.com/sug'

#设置单词存储区
A=[]
B=[]
C=[]
D=[]








#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================








while True:
#检测微信窗口是否存在
    handle=win32gui.FindWindow(None,'微信')
    if handle==0:
        print('\033c')
        print('微信都不打开，背个啥啊')
        print('快去打开微信再来找我')
        time.sleep(3)
        print('\033c')
        break

    #设置目标数量变量
    print('\033c')
    print('异常情况数：',errorsit)
    gradeanswer=input('请输入要背单词的数量:')

    #赛博bug半修复
    if gradeanswer=='':
        print('不打单词数量怎么背单词啊')
        time.sleep(1.5)
        print('\033c')
        continue
    elif '0' in gradeanswer or '1' in gradeanswer or '2' in gradeanswer or '3' in gradeanswer or '4' in gradeanswer or '5' in gradeanswer or '6' in gradeanswer or '7' in gradeanswer or '8' in gradeanswer or '9' in gradeanswer:
        if '.' in gradeanswer:
            print('单词数量怎么可能是小数')
            time.sleep(1.3)
            print('\033c')
            continue
        else:
            gradeanswer=int(gradeanswer)
    else:
        print('别瞎输，好好输')
        time.sleep(1)
        print('\033c')
        continue

    #设置已背单词变量
    answered=0

    #打开微信并打开在线签到助手聊天界面，再浅发个背单词
    wx=WeChat()
    wx.ChatWith('在线签到助手')
    wx.SendMsg('背单词')
        
    #如果已回答+错误情况<目标值
    while answered<gradeanswer:
        #延迟1.8秒执行
        time.sleep(1.8)

        #获取最后一条信息并储存
        lstmsg=wx.GetAllMessage()[-1]

        #获取单词并调用发送函数
        wd=GetWords()
        hd=Headers()
        transback=GetAndSend(wd,hd)

        #如果检测到“请在20秒内回复答案”，则为A、B、C、D分别设置切片起始变量
        if "请在20秒内回复答案" in lstmsg[1]:
            a_start=lstmsg[1].find("A. ")+len("A. ")
            a_end=lstmsg[1].find("B. ")
            b_start=lstmsg[1].find("B. ")+len("B. ")
            b_end=lstmsg[1].find("C. ")
            c_start=lstmsg[1].find("C. ")+len("C. ")
            c_end=lstmsg[1].find("D. ")
            d_start=lstmsg[1].find("D. ")+len("D. ")
            d_end=lstmsg[1].find("====================")

            #一个简单的异常处理
            if type(transback) != type('test') or type(transback)==type(None):
                wx.SendMsg('C')
                print('百度翻译抽风，遇事不决就选C')
                answered+=1
                errorsit+=1
                continue

            #在单词存储区存储“对应选项”的“对应汉字”
            opa=lstmsg[1][a_start:a_end].strip()
            A.append(opa)
            opb=lstmsg[1][b_start:b_end].strip()
            B.append(opb)
            opc=lstmsg[1][c_start:c_end].strip()
            C.append(opc)
            opd=lstmsg[1][d_start:d_end].strip()
            D.append(opd)

            #将选项分别转换为字符串
            strA="".join(A)
            strB="".join(B)
            strC="".join(C)
            strD="".join(D)

            #调用相似算法
            sima=SimilarMatching(strA,transback)
            simb=SimilarMatching(strB,transback)
            simc=SimilarMatching(strC,transback)
            simd=SimilarMatching(strD,transback)

            #微信内发送选项
            if sima>simb and sima>simc and sima>simd:
                wx.SendMsg("A")
            elif simb>sima and simb>simc and simb>simd:
                wx.SendMsg("B")
            elif simc>sima and simc>simb and simc>simd:
                wx.SendMsg("C")
            else:
                wx.SendMsg("D")

            #打印当前已背数量
            print('当前已背', answered+1 ,'个单词')

        #如果上述条件不成立，则执行检测“验证单词学习行为”的操作，切片验证码并发送
        elif "验证单词学习行为" in lstmsg[1]:
            #设置起始位置和验证码变量
            start_index = lstmsg[1].find("请回复") + len("请回复")
            end_index=lstmsg[1].find("验证单词学习行为")
            response=lstmsg[1][start_index:end_index].strip()

            #发送验证码            
            wx.SendMsg(response)

            #出现验证码情况，总计数-1，否则会提前结束程序，也会导致计数错误
            answered-=1

            #否则，发送“背单词”
        else:
            wx.SendMsg("背单词")
            answered-=1      
            
        #每次回答后，清空单词存储区
        A.clear()
        B.clear()
        C.clear()
        D.clear()

        #每循环一次，已背单词数+1
        answered+=1