#调整窗口大小
import os
os.system('mode con cols=45 lines=18')

#写入空值覆盖原结果
fway="C:\ProgramData\EnglishHelper"
finame='Results.txt'
fpath=os.path.join(fway,finame)
with open(fpath, "w", encoding="utf-8") as file:
    file.write('')

#导入所需模块
import time
import difflib
import requests
from wxauto import *

#定义相似算法函数
def SimilarMatching(A,transback):
    a=difflib.SequenceMatcher(None,A,transback).quick_ratio()
    return a

#定义报头函数
def Headers():
    #定义路径、文件名和path
    fway=r"C:\ProgramData\EnglishHelper"
    finame='Cookies.txt'
    fpath=os.path.join(fway,finame)

    #使用只读权限打开文件，设置content变量并作为报头一部分
    with open(fpath,'r') as file:
        content=file.read()
    headers={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    "Cookie": content 
    }
    return(headers)

#获取切片后的单词，以备发送
def GetWords():
    #设置起始位置
    start_index = lstmsg[1].find("【单选】") + len("【单选】")
    end_index = lstmsg[1].find("[")

    #获取字符串格式的单词本体并返回值
    gotword = lstmsg[1][start_index:end_index].strip()
    return gotword

#将获取到的单词发送至翻译提供商，并取得翻译结果
def GetAndSend(gottenword,Headers):
    try:
        response=requests.post(trans,headers=Headers,data={'kw':gottenword})
        response.raise_for_status()
        data=response.json().get('data')
        return data[0]['v'] if data else None
    except Exception as e:
        print(f"抽风信息：{e}")
        return None










#定义函数区
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#设置变量区







#设置正确单词变量
right=0

#设置验证码数量变量
verify=0

#设置错误单词变量
erroranswer=0

#设置超时单词变量
timeouted=0

#设置已背总数变量
totally=0

#占位
gradeanswer=0
errorsit=0

#设置翻译API提供商
trans='https://fanyi.baidu.com/sug'

#设置单词存储区
A=[]
B=[]
C=[]
D=[]








#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================








while True:
#检测微信窗口是否存在
    import win32gui
    handle=win32gui.FindWindow(None,'微信')
    if handle==0:
        print('\033c')
        print('微信都不打开，背个啥啊')
        print('快去打开微信再来找我')
        time.sleep(2)
        print('\033c')
        break

    #设置目标数量变量
    gradeanswer=input('请输入要背单词的数量:')

    #赛博bug半修复
    if gradeanswer=='':
        print('不打单词数量怎么背单词啊')
        time.sleep(1)
        print('\033c')
        continue
    elif '0' in gradeanswer or '1' in gradeanswer or '2' in gradeanswer or '3' in gradeanswer or '4' in gradeanswer or '5' in gradeanswer or '6' in gradeanswer or '7' in gradeanswer or '8' in gradeanswer or '9' in gradeanswer:
        if '.' in gradeanswer:
            print('单词数量怎么可能是小数')
            time.sleep(1)
            print('\033c')
            continue
        else:
            gradeanswer=int(gradeanswer)
    else:
        print('别瞎输，好好输')
        time.sleep(1)
        print('\033c')
        continue

    #设置错误情况变量
    errorsit=0

    #设置已背单词变量
    answered=0

    #设置并计算已背单词数量
    totally=totally+gradeanswer

    #打开微信并打开在线签到助手聊天界面，再浅发个背单词
    wx=WeChat()
    wx.ChatWith('在线签到助手')
    wx.SendMsg('背单词')
        
    #如果已回答+错误情况<目标值
    while answered+errorsit+timeouted<gradeanswer:
        #延迟1.8秒执行
        time.sleep(1.8)

        #获取最后一条信息并储存
        lstmsg=wx.GetAllMessage()[-1]

        #获取单词并调用发送函数
        wd=GetWords()
        hd=Headers()
        transback=GetAndSend(wd,hd)

        #如果检测到“请在20秒内回复答案”，则为A、B、C、D分别设置切片起始变量
        if "请在20秒内回复答案" in lstmsg[1]:
            a_start=lstmsg[1].find("A. ")+len("A. ")
            a_end=lstmsg[1].find("B. ")
            b_start=lstmsg[1].find("B. ")+len("B. ")
            b_end=lstmsg[1].find("C. ")
            c_start=lstmsg[1].find("C. ")+len("C. ")
            c_end=lstmsg[1].find("D. ")
            d_start=lstmsg[1].find("D. ")+len("D. ")
            d_end=lstmsg[1].find("====================")

            #一个简单的异常处理
            if type(transback) != type('test') or type(transback)==type(None):
                print('-------------------------------')
                print()
                print('出现错误，不算数，很有可能是cookie值错误')
                print('如果之前能背，那就是sb百度翻译又抽风辣')
                print('李彦宏！！！！')
                errorsit+=1
                print('遇事不决就选C')
                print()
                print('-------------------------------')
                wx.SendMsg('C')
                
            #打印当前已背数量
            print('-------------------------------')
            print()
            print('当前正在背第 ',answered+1,' 个单词')

            #检测单词正确数
            if "很棒！答题正确。"in lstmsg[1]:
                print('累计正确数：',(answered+1)-erroranswer-errorsit-timeouted)
                time.sleep(0.6)
        
            if "答题错误。正确答案" in lstmsg[1]:
                erroranswer+=1
                print('累计错误数：',erroranswer)
                time.sleep(0.6)

            if "答题超时" in lstmsg[1]:
                timeouted+=1
                print('累计超时数：',timeouted)
                time.sleep(0.6)

            #在单词存储区存储“对应选项”的“对应汉字”
            A.append(lstmsg[1][a_start:a_end].strip())
            B.append(lstmsg[1][b_start:b_end].strip())
            C.append(lstmsg[1][c_start:c_end].strip())
            D.append(lstmsg[1][d_start:d_end].strip())

            #将选项分别转换为字符串
            strA="".join(A)
            strB="".join(B)
            strC="".join(C)
            strD="".join(D)

            #调用相似算法
            sima=SimilarMatching(strA,transback)
            simb=SimilarMatching(strB,transback)
            simc=SimilarMatching(strC,transback)
            simd=SimilarMatching(strD,transback)

            #微信内发送选项
            if sima>simb and sima>simc and sima>simd:
                wx.SendMsg("A")
                print('算法匹配答案为：A，发送')
                print()
                print('-------------------------------')
            elif simb>sima and simb>simc and simb>simd:
                wx.SendMsg("B")
                print('算法匹配答案为：B，发送')
                print()
                print('-------------------------------')                
            elif simc>sima and simc>simb and simc>simd:
                wx.SendMsg("C")
                print('算法匹配答案为：C，发送')
                print()
                print('-------------------------------')                
            else:
                print('算法匹配答案为：D，发送')
                wx.SendMsg("D")
                print()
                print('-------------------------------')                

            #用户要求只背一个单词情况下的统计数bug修复
                if gradeanswer==int(1):
                    time.sleep(2)
                    lstmsg=wx.GetAllMessage()[-1]
                    if "很棒！答题正确。"in lstmsg[1]:
                        right=gradeanswer-erroranswer

                    if "答题错误。正确答案" in lstmsg[1]:
                        erroranswer+=1

                    if "答题超时" in lstmsg[1]:
                        timeouted+=1

        #如果上述条件不成立，则执行检测“验证单词学习行为”的操作，切片验证码并发送
        elif "验证单词学习行为" in lstmsg[1]:
            #设置起始位置
            start_index = lstmsg[1].find("请回复") + len("请回复")
            end_index=lstmsg[1].find("验证单词学习行为")

            #设置变量veristr为发送字符串格式的切片(验证码)
            veristr=lstmsg[1][start_index:end_index].strip()
            wx.SendMsg(veristr)
            print()
            print('该死的验证码：',veristr)
            print('又尼玛不算正确词')
            print("输他丫的")
            print()
            print('-------------------------------')
            #设置findcurrency为获取全部消息的倒数第三条，并判断该单词是否正确
            findcurrency=wx.GetAllMessage()[-3]
            if '很棒！答题正确。' in findcurrency[1]:
                (answered+1)-erroranswer
            #验证码值+1，并发送veristr
            verify+=1

            #出现验证码情况，总计数-1，否则会提前结束程序，也会导致计数错误
            answered-=1

            #否则，发送“背单词”
        else:
            print('-------------------------------')
            print()
            print('如果出现反复发送背单词的情况，建议检查网络')
            print('如果网络过于卡顿，会导致程序无法及时获取单词')
            print('从而一直尝试发送背单词')
            print()
            print('-------------------------------')
            wx.SendMsg("背单词")
            answered-=1            
            
        #每次回答后，清空单词存储区
        A.clear()
        B.clear()
        C.clear()
        D.clear()

        #每循环一次，已背单词数+1
        answered+=1

    #背完单词后，写入结果并退出程序
    if answered == gradeanswer:
        def write_text_to_file(text, file_path):
            with open(fpath, "a", encoding="utf-8") as file:
                file.write(text)

        if __name__ == "__main__":
            # 要写入的文本内容
            text_to_save1 = '已背单词数量：'+str(totally)
            text_to_save2 = '\n错误数：'+str(erroranswer)
            text_to_save3 = '\n正确数：'+str(answered-erroranswer-timeouted-errorsit)
            text_to_save4 = '\n验证码数：'+str(verify)
            text_to_save5 = '\n超时数量：'+str(timeouted)
            text_to_save6 = '\n错误情况：'+str(errorsit)
            text_to_save7 = '\n统计数据仅供参考，且只统计当前程序运行周期数据'
            text_to_save8 = '\n可能会有误差'

            # 文件保存路径
            fway="C:\ProgramData\EnglishHelper"
            finame='Results.txt'
            fpath=os.path.join(fway,finame)

            # 写入文件
            write_text_to_file(text_to_save1, fpath)
            write_text_to_file(text_to_save2, fpath)
            write_text_to_file(text_to_save3, fpath)
            write_text_to_file(text_to_save4, fpath)
            write_text_to_file(text_to_save5, fpath)
            write_text_to_file(text_to_save6, fpath)
            write_text_to_file(text_to_save7, fpath)
            write_text_to_file(text_to_save8, fpath)
            break