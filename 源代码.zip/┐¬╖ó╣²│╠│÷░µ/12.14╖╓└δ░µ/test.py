#赛博优化代码
print('---------------------')
print()
print('请在背单词之前打开并登录微信\n否则程序会因为无法找到微信窗口报错退出')
print()
print('---------------------')
print()
import os
os.system('mode con cols=60 lines=20')

#导入所需模块
import time
import difflib
from wxauto import *

#定义相似算法函数
def SimilarMatching(A,transback):
    a=difflib.SequenceMatcher(None,A,transback).quick_ratio()
    return a

#定义报头函数
def Headers():
    #定义路径、文件名和path
    fway=r"C:\ProgramData\EnglishHelper"
    finame='Cookies.txt'
    fpath=os.path.join(fway,finame)

    #使用只读权限打开文件，设置content变量并作为报头一部分
    with open(fpath,'r') as file:
        content=file.read()
    headers={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    "Cookie": content 
    }
    return(headers)

#获取切片后的单词，以备发送
def GetWords():
    #设置起始位置
    start_index = lstmsg[1].find("【单选】") + len("【单选】")
    end_index = lstmsg[1].find("[")

    #获取字符串格式的单词本体并返回值
    gotword = lstmsg[1][start_index:end_index].strip()
    return gotword

#将获取到的单词发送至翻译提供商，并取得翻译结果
def GetAndSend(gottenword,Headers):
    try:
        response=requests.post(trans,headers=Headers,data={'kw':gottenword})
        response.raise_for_status()
        data=response.json().get('data')
        return data[0]['v'] if data else None
    except Exception as e:
        print(f"抽风信息：{e}")
        return None

#定义统计函数
def AllResults():
    print("\033c",end="")
    print('---------------------')
    print()
    print('总结')
    print('已背单词数量：',totally)
    print('错误数：',erroranswer)
    print('正确数：',right)
    print('验证码数：',verify)
    print("超时数量：",timeouted)
    print('错误情况：',errorsit)
    print('重试次数：',int(retry-gradeanswer/10))
    print('统计数据仅供参考，且只统计当前程序运行周期数据')
    print('可能会有误差')
    print()
    print('---------------------')










#定义函数区
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#设置变量区







#设置正确单词变量
right=0

#设置验证码数量变量
verify=0

#设置错误单词变量
erroranswer=0

#设置超时单词变量
timeouted=0

#设置已背总数变量
totally=0

#设置重试次数变量
retry=0

#占位
gradeanswer=0
errorsit=0

#设置翻译API提供商
trans='https://fanyi.baidu.com/sug'

#设置单词存储区
A=[]
B=[]
C=[]
D=[]








#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================
#======================================================================================================================









#开始决定程序行为辣
while True:
    print('整么？')
    print('1.查看背单词日志')
    print('2.整')
    print('3.不整了，退出')
    choice=str(input('请选择操作对应编号(1-2-3)：'))

    if choice==str(1):
        AllResults()

    elif choice==str(2):
        #清空控制台
        print('\033c',end='')
        #设置目标数量变量
        gradeanswer=int(input('请输入要背单词的数量，请输入整数，否则程序会报错退出:'))
        
        #赛博防出错+赛博优化
        import requests

        #设置错误情况变量
        errorsit=0

        #设置已背单词变量
        answered=0

        #设置并计算已背单词数量
        totally=totally+gradeanswer

        #打开微信并打开在线签到助手聊天界面，再浅发个背单词
        wx=WeChat()
        wx.ChatWith('在线签到助手')
        wx.SendMsg('背单词')
        
        #如果已回答+错误情况<目标值
        while answered+errorsit<gradeanswer:
            #延迟2秒执行
            time.sleep(2)

            #获取最后一条信息并储存
            lstmsg=wx.GetAllMessage()[-1]

            #获取单词并调用发送函数
            wd=GetWords()
            hd=Headers()
            transback=GetAndSend(wd,hd)

            #如果检测到“请在20秒内回复答案”，则为A、B、C、D分别设置切片起始变量
            if "请在20秒内回复答案" in lstmsg[1]:
                a_start=lstmsg[1].find("A. ")+len("A. ")
                a_end=lstmsg[1].find("B. ")
                b_start=lstmsg[1].find("B. ")+len("B. ")
                b_end=lstmsg[1].find("C. ")
                c_start=lstmsg[1].find("C. ")+len("C. ")
                c_end=lstmsg[1].find("D. ")
                d_start=lstmsg[1].find("D. ")+len("D. ")
                d_end=lstmsg[1].find("====================")

                #一个简单的异常处理
                if type(transback) != type('test'):
                    print('-------------------------------')
                    print()
                    print('出现错误，不算数，很有可能是cookie值错误')
                    print('如果之前能背，那就是sb百度翻译又抽风辣')
                    print('李彦宏！！！！')
                    errorsit+=1
                    print('遇事不决就选C')
                    print()
                    print('-------------------------------')
                    wx.SendMsg('C')
                    continue

                #打印当前已背数量
                print('-------------------------------')
                print()
                print('当前正在背第 ',answered+1,' 个单词')

                #延迟0.5秒执行
                time.sleep(0.5)

                #检测单词正确数
                if "很棒！答题正确。"in lstmsg[1]:
                    right+=1
                    print('累计正确数：',right)
                    time.sleep(0.8)
        
                if "答题错误。正确答案" in lstmsg[1]:
                    erroranswer+=1
                    print('累计错误数：',erroranswer)
                    time.sleep(0.8)

                if "答题超时" in lstmsg[1]:
                    timeouted+=1
                    print('累计超时数：',right)
                    time.sleep(0.8)

                #在单词存储区存储“对应选项”的“对应汉字”
                A.append(lstmsg[1][a_start:a_end].strip())
                B.append(lstmsg[1][b_start:b_end].strip())
                C.append(lstmsg[1][c_start:c_end].strip())
                D.append(lstmsg[1][d_start:d_end].strip())

                #将选项分别转换为字符串
                strA="".join(A)
                strB="".join(B)
                strC="".join(C)
                strD="".join(D)

                #调用相似算法
                sima=SimilarMatching(strA,transback)
                simb=SimilarMatching(strB,transback)
                simc=SimilarMatching(strC,transback)
                simd=SimilarMatching(strD,transback)

                #微信内发送选项
                if sima>simb and sima>simc and sima>simd:
                    print('算法匹配答案为：A，发送')
                    print()
                    print('-------------------------------')
                    wx.SendMsg("A")
                elif simb>sima and simb>simc and simb>simd:
                    print('算法匹配答案为：B，发送')
                    print()
                    print('-------------------------------')
                    wx.SendMsg("B")
                elif simc>sima and simc>simb and simc>simd:
                    print('算法匹配答案为：C，发送')
                    print()
                    print('-------------------------------')
                    wx.SendMsg("C")
                else:
                    print('算法匹配答案为：D，发送')
                    print()
                    print('-------------------------------')
                    wx.SendMsg("D")

            #用户要求只背一个单词情况下的统计数bug修复
                if gradeanswer==int(1):
                    time.sleep(2)
                    lstmsg=wx.GetAllMessage()[-1]
                    if "很棒！答题正确。"in lstmsg[1]:
                        right+=1

                    if "答题错误。正确答案" in lstmsg[1]:
                        erroranswer+=1

                    if "答题超时" in lstmsg[1]:
                        timeouted+=1

            #如果上述条件不成立，则执行检测“验证单词学习行为”的操作，切片验证码并发送
            elif "验证单词学习行为" in lstmsg[1]:
                #设置起始位置
                start_index = lstmsg[1].find("请回复") + len("请回复")
                end_index=lstmsg[1].find("验证单词学习行为")

                #设置变量veristr为发送字符串格式的切片(验证码)
                veristr=lstmsg[1][start_index:end_index].strip()
                print()
                print('该死的验证码：',veristr)
                print('又尼玛不算正确词')
                print("输他丫的")
                print()
                print('-------------------------------')
                #设置findcurrency为获取全部消息的倒数第三条，并判断该单词是否正确
                findcurrency=wx.GetAllMessage()[-3]
                if '很棒！答题正确。' in findcurrency[1]:
                    right+=1
                #验证码值+1，并发送veristr
                verify+=1
                wx.SendMsg(veristr)

                #出现验证码情况，总计数-1，否则会提前结束程序，也会导致计数错误
                answered-=1

            #否则，发送“背单词”
            else:
                print('-------------------------------')
                print()
                print('如果出现反复发送背单词的情况，建议检查网络')
                print('如果网络过于卡顿，会导致程序无法及时获取单词')
                print('从而一直尝试发送背单词')
                print()
                print('-------------------------------')
                wx.SendMsg("背单词")
                answered-=1
                retry+=1
            
            #每次回答后，清空单词存储区
            A.clear()
            B.clear()
            C.clear()
            D.clear()

            #每循环一次，已背单词数+1
            answered+=1

            #背完单词后，清空控制台
            if answered == gradeanswer:
                print('\033c',end='')

    elif choice==str(3):
        print("\033c",end="")
        print('拜拜了您内，欢迎下次来玩')
        time.sleep(0.6)
        break

    else:
        print('\033c',end='')
        print('别瞎选，好好选')
        print()