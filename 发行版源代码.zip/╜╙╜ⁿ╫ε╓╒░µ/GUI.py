import tkinter as tk
from tkinter import messagebox
from tkinter import Menu
import os
def anticlose():
    pass
def cut():
    entry.event_generate("<<Cut>>")
def copy():
    entry.event_generate("<<Copy>>")
def paste():
    entry.event_generate("<<Paste>>")
delway=r"C:\ProgramData\EnglishHelper"
delname="Results.txt"
delpath=os.path.join(delway,delname)
with open(delpath,'w',encoding='utf-8') as file:
    file.write('日志为空')
    file.close
fway=r"C:\ProgramData\EnglishHelper"
finame='Cookies.txt'
fpath=os.path.join(fway,finame)
def set_cookie():
    if not os.path.exists(fway):
        os.makedirs(fway)
    else:
        pass
    cookie = entry.get()
    with open(fpath,'w') as file:
        file.write(cookie)    
        file.close()
        tk.messagebox.showinfo('恭喜','写入成功')
        with open(fpath,'r') as file:
            content=file.read()
            if content=="":
                tk.messagebox.showerror('你大爷','Cookie值为空背鸡毛，老子不干了')
            else:
                root.destroy()
root = tk.Tk()
root.title("请输入Cookie")
root.geometry("600x620+80+60")
root.resizable(width=False, height=False)
root.protocol("WM_DELETE_WINDOW",anticlose)
tk.Label(root, text="特别感谢：老柳、田哥；没有你们，就不会有本程序\n特别感谢：耿哥；没有你的issue，就不会有体验优化\n同时也是键盘提供者，没有他的键盘，我不会肝的这么快\n特别感谢：每一个陪我debug的人，没有你们，我就不会发现可能隐含在程序中的bug", font=("Microsoft YaHei", 10)).pack(pady=35)
tk.Label(root, text="------------------------------------------------------------", font=("Microsoft YaHei", 10)).pack(pady=0)
tk.Label(root, text="请到百度翻译网页获取Cookie，粘贴至下方输入框\n粘贴后点击设置Cookie\n出现”写入成功“即可进入主程序", font=("Microsoft YaHei", 10)).pack(pady=35)
tk.Label(root, text="------------------------------------------------------------", font=("Microsoft YaHei", 10)).pack(pady=0)
tk.Label(root, text="获取Token方法：打开浏览器并访问百度翻译官网，进入浏览器的开发者工具\n点击网络-Fetch/XHR\n在官网随意输入一个词后，去右侧点击translate\n复制Cookie值即可", font=("Microsoft YaHei", 10)).pack(pady=35)
entry = tk.Entry(root,width=64)
entry.pack(pady=0)
menu = Menu(root, tearoff=0)
menu.add_command(label="剪切", command=cut)
menu.add_command(label="复制", command=copy)
menu.add_command(label="粘贴", command=paste)
def show_menu(event):
    menu.post(event.x_root, event.y_root)
entry.bind("<Button-3>", show_menu)
tk.Button(root, text="设置 Cookie", command=set_cookie).pack(pady=35)
root.mainloop()
def exit_program():
    main.destroy()
def AllResults():
    fway=r"C:\ProgramData\EnglishHelper"
    finame='Results.txt'
    fpath=os.path.join(fway,finame)
    with open(fpath, "r", encoding="utf-8") as file:
        content = file.read()
    messagebox.showinfo("统计数据", content)
main = tk.Tk()
main.title("去你大爷的英语单词")
main.geometry("320x273+80+60")
main.resizable(width=False, height=False)
tk.Label(main, text="做出选择的时刻到了", font=("Microsoft YaHei", 10)).pack(pady=21)
tk.Button(main, text="查看背单词日志", command=AllResults).pack(pady=10)
def startanswer():
    tk.messagebox.showinfo('注意','本程序为模拟人类点击操作\n主程序运行过程中尽可能不要触碰电脑\n否则可能会因为操作冲突导致背单词失败')
    tk.messagebox.showinfo('注意','请在背单词之前打开并登录微信\n登录微信后点击确定\n点击确定后将打开背单词主程序')
    os.system('FuckEnglish.exe')
tk.Button(main, text="整", command=startanswer).pack(pady=10)
tk.Button(main, text="不整了，退出", command=exit_program).pack(pady=10)
main.mainloop()
os.remove(delpath)